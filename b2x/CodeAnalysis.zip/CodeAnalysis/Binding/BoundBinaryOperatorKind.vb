﻿Namespace Basic.CodeAnalysis.Binding

  Friend Enum BoundBinaryOperatorKind
    Addition
    Subtraction
    Multiplication
    Division
    IntegerDivision
    LogicalAndAlso
    LogicalAnd
    LogicalOr
    LogicalOrElse
    OrOperation
    XorOperation
    LogicalEqv
    InpOperation
    ModOperation
    LogicalImp
    ImpOperation
    EqvOperation
    AndOperation
    GreaterThan
    GreaterThanEqual
    Equal
    NotEqual
    LessThan
    LessThanEqual
  End Enum

End Namespace