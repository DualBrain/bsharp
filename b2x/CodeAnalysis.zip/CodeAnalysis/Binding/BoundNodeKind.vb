﻿Namespace Basic.CodeAnalysis.Binding

  Friend Enum BoundNodeKind
    LiteralExpression
    UnaryExpression
    BinaryExpression
  End Enum

End Namespace