﻿Namespace Basic.CodeAnalysis.Binding

  Friend Enum BoundUnaryOperatorKind
    Identity
    Negation
    LogicalNegation
  End Enum

End Namespace