﻿Namespace Basic.CodeAnalysis.Binding

  Friend MustInherit Class BoundNode

    Public MustOverride ReadOnly Property Kind As BoundNodeKind

  End Class

End Namespace