﻿Imports Basic.CodeAnalysis.Syntax

Namespace Basic.CodeAnalysis.Binding

  Friend NotInheritable Class Binder

    Private ReadOnly m_diagnostics As New List(Of String)

    Public ReadOnly Property Diagnostics As IEnumerable(Of String)
      Get
        Return m_diagnostics
      End Get
    End Property

    Public Function BindExpression(syntax As ExpressionSyntax) As BoundExpression
      Select Case syntax.Kind
        Case SyntaxKind.LiteralExpression : Return BindLiteralExpression(CType(syntax, LiteralExpressionSyntax))
        Case SyntaxKind.UnaryExpression : Return BindUnaryExpression(CType(syntax, UnaryExpressionSyntax))
        Case SyntaxKind.BinaryExpression : Return BindBinaryExpression(CType(syntax, BinaryExpressionSyntax))
        Case SyntaxKind.ParenthesizedExpression : Return BindExpression(CType(syntax, ParenthesizedExpressionSyntax).Expression)
        Case Else
          Throw New Exception($"Unexpected syntax {syntax.Kind}")
      End Select
    End Function

    Private Shared Function BindLiteralExpression(syntax As LiteralExpressionSyntax) As BoundExpression
      Dim value = If(syntax.Value, 0)
      Return New BoundLiteralExpression(value)
    End Function

    Private Function BindUnaryExpression(syntax As UnaryExpressionSyntax) As BoundExpression
      Dim boundOperand = BindExpression(syntax.Operand)
      Dim boundOperator = BoundUnaryOperator.Bind(syntax.OperatorToken.Kind, boundOperand.Type)
      If boundOperator Is Nothing Then
        m_diagnostics.Add($"Unary operator '{syntax.OperatorToken.Text}' is not defined for type {boundOperand.Type}")
        Return boundOperand
      End If
      Return New BoundUnaryExpression(boundOperator, boundOperand)
    End Function

    Private Function BindBinaryExpression(syntax As BinaryExpressionSyntax) As BoundExpression
      Dim boundLeft = BindExpression(syntax.Left)
      Dim boundRight = BindExpression(syntax.Right)
      Dim boundOperator = BoundBinaryOperator.Bind(syntax.OperatorToken.Kind, boundLeft.Type, boundRight.Type)
      If boundOperator Is Nothing Then
        m_diagnostics.Add($"Binary operator '{syntax.OperatorToken.Text}' is not defined for type {boundLeft.Type} and {boundRight.Type}")
        Return boundLeft
      End If
      Return New BoundBinaryExpression(boundLeft, boundOperator, boundRight)
    End Function

    Private Shared Function BindUnaryOperatorKind(kind As SyntaxKind, operandType As Type) As BoundUnaryOperatorKind?

      If operandType = GetType(Integer) Then
        Select Case kind
          Case SyntaxKind.PlusToken : Return BoundUnaryOperatorKind.Identity
          Case SyntaxKind.MinusToken : Return BoundUnaryOperatorKind.Negation
          Case Else
        End Select
      End If

      If operandType = GetType(Boolean) Then
        Select Case kind
          Case SyntaxKind.NotKeyword : Return BoundUnaryOperatorKind.LogicalNegation
          Case Else
        End Select
      End If

      Return Nothing

    End Function

    Private Shared Function BindBinaryOperatorKind(kind As SyntaxKind, leftType As Type, rightType As Type) As BoundBinaryOperatorKind?

      If leftType = GetType(Integer) AndAlso rightType = GetType(Integer) Then
        Select Case kind
          Case SyntaxKind.PlusToken : Return BoundBinaryOperatorKind.Addition
          Case SyntaxKind.MinusToken : Return BoundBinaryOperatorKind.Subtraction
          Case SyntaxKind.StarToken : Return BoundBinaryOperatorKind.Multiplication
          Case SyntaxKind.SlashToken : Return BoundBinaryOperatorKind.Division
          Case SyntaxKind.BackslashToken : Return BoundBinaryOperatorKind.IntegerDivision

          Case SyntaxKind.ModKeyword : Return BoundBinaryOperatorKind.ModOperation
          Case SyntaxKind.AndKeyword : Return BoundBinaryOperatorKind.AndOperation
          Case SyntaxKind.OrKeyword : Return BoundBinaryOperatorKind.OrOperation
          Case SyntaxKind.XorKeyword : Return BoundBinaryOperatorKind.XorOperation
          Case SyntaxKind.EqvKeyword : Return BoundBinaryOperatorKind.EqvOperation
          Case SyntaxKind.ImpKeyword : Return BoundBinaryOperatorKind.ImpOperation

          Case Else
        End Select
      End If

      If leftType = GetType(Boolean) AndAlso rightType = GetType(Boolean) Then
        Select Case kind
          Case SyntaxKind.AndKeyword : Return BoundBinaryOperatorKind.LogicalAnd
          Case SyntaxKind.OrKeyword : Return BoundBinaryOperatorKind.LogicalOr
          Case SyntaxKind.AndAlsoKeyword : Return BoundBinaryOperatorKind.LogicalAndAlso
          Case SyntaxKind.OrElseKeyword : Return BoundBinaryOperatorKind.LogicalOrElse
          Case SyntaxKind.EqvKeyword : Return BoundBinaryOperatorKind.LogicalEqv
          Case SyntaxKind.ImpKeyword : Return BoundBinaryOperatorKind.LogicalImp
          Case Else
        End Select
      End If

      Return Nothing

    End Function

  End Class

End Namespace