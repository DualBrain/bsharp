﻿Imports Basic.CodeAnalysis.Binding
Imports Basic.CodeAnalysis.Syntax

Namespace Basic.CodeAnalysis

  ' This Evaluator utilizes the "Bound Tree" (very similar to the AST).
  Friend NotInheritable Class Evaluator

    Private ReadOnly m_root As BoundExpression

    Sub New(root As BoundExpression)
      m_root = root
    End Sub

    Public Function Evaluate() As Object
      Return EvaluateExpression(m_root)
    End Function

    Private Function EvaluateExpression(node As BoundExpression) As Object

      If TypeOf node Is BoundLiteralExpression Then
        Dim n = CType(node, BoundLiteralExpression)
        Return n.Value
      End If

      If TypeOf node Is BoundUnaryExpression Then
        Dim u = CType(node, BoundUnaryExpression)
        Dim operand = EvaluateExpression(u.Operand)
        Select Case u.Op.Kind
          Case BoundUnaryOperatorKind.Identity : Return CInt(operand)
          Case BoundUnaryOperatorKind.Negation : Return -CInt(operand)
          Case BoundUnaryOperatorKind.LogicalNegation : Return Not CBool(operand)
          Case Else
            Throw New Exception($"Unexpected unary operator {u.Op}")
        End Select
      End If

      If TypeOf node Is BoundBinaryExpression Then
        Dim b = CType(node, BoundBinaryExpression)
        Dim left = EvaluateExpression(b.Left)
        Dim right = EvaluateExpression(b.Right)
        Select Case b.Op.Kind

          Case BoundBinaryOperatorKind.Addition : Return CInt(left) + CInt(right)
          Case BoundBinaryOperatorKind.Subtraction : Return CInt(left) - CInt(right)
          Case BoundBinaryOperatorKind.Multiplication : Return CInt(left) * CInt(right)
          Case BoundBinaryOperatorKind.Division : Return CInt(CInt(left) / CInt(right))
          Case BoundBinaryOperatorKind.IntegerDivision : Return CInt(left) \ CInt(right)
          Case BoundBinaryOperatorKind.AndOperation : Return CInt(left) And CInt(right)
          Case BoundBinaryOperatorKind.OrOperation : Return CInt(left) Or CInt(right)
          Case BoundBinaryOperatorKind.XorOperation : Return CInt(left) Xor CInt(right)
          Case BoundBinaryOperatorKind.ModOperation : Return CInt(left) Mod CInt(right)

          Case BoundBinaryOperatorKind.LogicalEqv : Return CBool(left) = CBool(right)
          Case BoundBinaryOperatorKind.LogicalImp : Return CBool(left) AndAlso Not CBool(right)
          Case BoundBinaryOperatorKind.LogicalAnd : Return CBool(left) And CBool(right)
          Case BoundBinaryOperatorKind.LogicalOr : Return CBool(left) Or CBool(right)
          Case BoundBinaryOperatorKind.LogicalAndAlso : Return CBool(left) AndAlso CBool(right)
          Case BoundBinaryOperatorKind.LogicalOrElse : Return CBool(left) OrElse CBool(right)

          Case BoundBinaryOperatorKind.GreaterThan : Return CInt(left) > CInt(right)
          Case BoundBinaryOperatorKind.GreaterThanEqual : Return CInt(left) >= CInt(right)
          Case BoundBinaryOperatorKind.LessThanEqual : Return CInt(left) <= CInt(right)
          Case BoundBinaryOperatorKind.LessThan : Return CInt(left) < CInt(right)

          Case BoundBinaryOperatorKind.Equal : Return Equals(left, right)
          Case BoundBinaryOperatorKind.NotEqual : Return Not Equals(left, right)

          Case Else
            Throw New Exception($"Unexpected binary operator {b.Op.Kind}")
        End Select
      End If

      Throw New Exception($"Unexpected node {node.Kind}")

    End Function

  End Class

  ' This Evaluator walks the "raw" SyntaxTree.
  Public NotInheritable Class Evaluator_SyntaxTree

    Private ReadOnly m_root As ExpressionSyntax

    Sub New(root As ExpressionSyntax)
      m_root = root
    End Sub

    Public Function Evaluate() As Integer
      Return EvaluateExpression(m_root)
    End Function

    Private Function EvaluateExpression(node As ExpressionSyntax) As Integer

      If TypeOf node Is LiteralExpressionSyntax Then
        Return CInt(CType(node, LiteralExpressionSyntax).LiteralToken.Value)
      End If

      If TypeOf node Is UnaryExpressionSyntax Then
        Dim u = CType(node, UnaryExpressionSyntax)
        Dim operand = EvaluateExpression(u.Operand)
        Select Case u.OperatorToken.Kind
          Case SyntaxKind.PlusToken : Return operand
          Case SyntaxKind.MinusToken : Return -operand
          Case Else
            Throw New Exception($"Unexpected unary operator {u.OperatorToken.Kind}")
        End Select
      End If

      If TypeOf node Is BinaryExpressionSyntax Then
        Dim b = CType(node, BinaryExpressionSyntax)
        Dim left = EvaluateExpression(b.Left)
        Dim right = EvaluateExpression(b.Right)
        Select Case b.OperatorToken.Kind
          Case SyntaxKind.PlusToken : Return left + right
          Case SyntaxKind.MinusToken : Return left - right
          Case SyntaxKind.StarToken : Return left * right
          Case SyntaxKind.SlashToken : Return CInt(left / right)
          Case SyntaxKind.BackslashToken : Return left \ right
          Case Else
            Throw New Exception($"Unexpected binary operator {b.OperatorToken.Kind}")
        End Select
      End If

      If TypeOf node Is ParenthesizedExpressionSyntax Then
        Dim p = CType(node, ParenthesizedExpressionSyntax)
        Return EvaluateExpression(p.Expression)
      End If

      Throw New Exception($"Unexpected node {node.Kind}")

    End Function

  End Class

End Namespace