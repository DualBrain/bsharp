﻿Namespace Basic.CodeAnalysis.Syntax

  Public MustInherit Class SyntaxNode

    MustOverride ReadOnly Property Kind As SyntaxKind

    Public MustOverride Iterator Function GetChildren() As IEnumerable(Of SyntaxNode)

  End Class

End Namespace