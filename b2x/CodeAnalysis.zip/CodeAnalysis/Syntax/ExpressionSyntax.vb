﻿Namespace Basic.CodeAnalysis.Syntax

  Public MustInherit Class ExpressionSyntax
    Inherits SyntaxNode

  End Class

End Namespace