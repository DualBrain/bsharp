﻿Namespace Basic.CodeAnalysis.Syntax

  Friend NotInheritable Class Lexer

    Private ReadOnly m_text As String
    Private m_position As Integer

    Private ReadOnly m_diagnostics As New List(Of String)

    Public Sub New(text As String)
      m_text = text
    End Sub

    Public ReadOnly Property Diagnostics As IEnumerable(Of String)
      Get
        Return m_diagnostics
      End Get
    End Property

    Private ReadOnly Property Current() As Char
      Get
        Return Peek(0)
      End Get
    End Property

    Private ReadOnly Property LookAhead() As Char
      Get
        Return Peek(1)
      End Get
    End Property

    Private ReadOnly Property Peek(offset As Integer) As Char
      Get
        Dim index = m_position + offset
        If index >= m_text.Length Then Return Chr(0)
        Return m_text(index)
      End Get
    End Property

    Private Sub [Next]()
      m_position += 1
    End Sub

    Public Function Lex() As SyntaxToken

      If m_position >= m_text.Length Then
        Return New SyntaxToken(SyntaxKind.EndOfFileToken, m_position, Chr(0), Nothing)
      End If

      If Char.IsDigit(Current) Then
        Dim start = m_position
        While Char.IsDigit(Current)
          [Next]()
        End While
        Dim length = m_position - start
        Dim text = m_text.Substring(start, length)
        Dim value As Integer
        If Not Integer.TryParse(text, value) Then
          m_diagnostics.Add($"ERROR: The number {m_text} isn't a valid Int32")
        End If
        Return New SyntaxToken(SyntaxKind.NumberToken, start, text, value)
      End If

      If Char.IsWhiteSpace(Current) Then
        Dim start = m_position
        While Char.IsWhiteSpace(Current)
          [Next]()
        End While
        Dim length = m_position - start
        Dim text = m_text.Substring(start, length)
        'Dim value As Integer : Integer.TryParse(text, value)
        Return New SyntaxToken(SyntaxKind.WhitespaceToken, start, text, Nothing)
      End If

      ' true and false
      If Char.IsLetter(Current) Then
        Dim start = m_position
        While Char.IsLetter(Current)
          [Next]()
        End While
        Dim length = m_position - start
        Dim text = m_text.Substring(start, length)
        Dim kind = SyntaxFacts.GetKeywordKind(text)
        Return New SyntaxToken(kind, start, text, Nothing)
      End If

      Select Case Current
        Case "+"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.PlusToken, m_position - 1, "+", Nothing)
        Case "-"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.MinusToken, m_position - 1, "-", Nothing)
        Case "*"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.StarToken, m_position - 1, "*", Nothing)
        Case "/"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.SlashToken, m_position - 1, "/", Nothing)
        Case "\"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.BackslashToken, m_position - 1, "\", Nothing)
        Case "^"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.HatToken, m_position - 1, "^", Nothing)
        Case "("c : m_position += 1 : Return New SyntaxToken(SyntaxKind.OpenParenToken, m_position - 1, "(", Nothing)
        Case ")"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.CloseParenToken, m_position - 1, ")", Nothing)
        Case "="c : m_position += 1 : Return New SyntaxToken(SyntaxKind.EqualToken, m_position - 1, "=", Nothing)

        Case ">"c ' > >=
          If LookAhead = "="c Then
            m_position += 2 : Return New SyntaxToken(SyntaxKind.GreaterThanEqualToken, m_position - 2, ">=", Nothing)
          Else
            m_position += 1 : Return New SyntaxToken(SyntaxKind.GreaterThanToken, m_position - 1, ">", Nothing)
          End If

        Case "<"c ' < <= <>
          If LookAhead = "="c Then
            m_position += 2 : Return New SyntaxToken(SyntaxKind.LessThanEqualToken, m_position - 2, "<=", Nothing)
          ElseIf LookAhead = ">"c Then
            m_position += 2 : Return New SyntaxToken(SyntaxKind.LessThanGreaterThanToken, m_position - 2, "<>", Nothing)
          Else
            m_position += 1 : Return New SyntaxToken(SyntaxKind.LessThanToken, m_position - 1, "<", Nothing)
          End If

        Case "."c : m_position += 1 : Return New SyntaxToken(SyntaxKind.PeriodToken, m_position - 1, ".", Nothing)
        Case ":"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.ColonToken, m_position - 1, ":", Nothing)
        Case ";"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.SemicolonToken, m_position - 1, ";", Nothing)
        Case "?"c : m_position += 1 : Return New SyntaxToken(SyntaxKind.QuestionToken, m_position - 1, "?", Nothing)
        Case Else
      End Select

      m_diagnostics.Add($"ERROR: bad character input: '{Current}'")
      m_position += 1
      Return New SyntaxToken(SyntaxKind.BadToken, m_position, m_text.Substring(m_position - 1, 1), Nothing)

    End Function

  End Class

End Namespace