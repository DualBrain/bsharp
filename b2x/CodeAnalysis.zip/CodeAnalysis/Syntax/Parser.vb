﻿Namespace Basic.CodeAnalysis.Syntax

  Friend NotInheritable Class Parser

    Private ReadOnly m_tokens As SyntaxToken()
    Private m_position As Integer

    Private ReadOnly m_diagnostics As New List(Of String)

    Public Sub New(text As String)

      Dim tokens = New List(Of SyntaxToken)
      Dim lexer = New Lexer(text)
      Dim token As SyntaxToken
      Do

        token = lexer.Lex

        If token.Kind <> SyntaxKind.WhitespaceToken AndAlso
         token.Kind <> SyntaxKind.BadToken Then
          tokens.Add(token)
        End If

      Loop While token.Kind <> SyntaxKind.EndOfFileToken

      m_tokens = tokens.ToArray

      m_diagnostics.AddRange(lexer.Diagnostics)

    End Sub

    Public ReadOnly Property Diagnostics As IEnumerable(Of String)
      Get
        Return m_diagnostics
      End Get
    End Property

    Private Function Peek(offset As Integer) As SyntaxToken
      Dim index = m_position + offset
      If index >= m_tokens.Length Then
        Return m_tokens(m_tokens.Length - 1)
      End If
      Return m_tokens(index)
    End Function

    Private Function Current() As SyntaxToken
      Return Peek(0)
    End Function

    Private Function NextToken() As SyntaxToken
      Dim current = Me.Current
      m_position += 1
      Return current
    End Function

    Private Function MatchToken(kind As SyntaxKind) As SyntaxToken
      If Current.Kind = kind Then
        Return NextToken()
      End If
      m_diagnostics.Add($"ERROR: Unexpected token <{Current.Kind}>, expected <{kind}>")
      Return New SyntaxToken(kind, Current.Position, Nothing, Nothing)
    End Function

    Public Function Parse() As SyntaxTree

      Dim expression = ParseExpression()
      Dim endOfFileToken = MatchToken(SyntaxKind.EndOfFileToken)
      Return New SyntaxTree(m_diagnostics, expression, endOfFileToken)

    End Function

    Private Function ParseExpression(Optional parentPrecedence As Integer = 0) As ExpressionSyntax

      Dim left As ExpressionSyntax
      Dim unaryOperatorPrecedence = SyntaxFacts.GetUnaryOperatorPrecedence(Current.Kind)
      If unaryOperatorPrecedence <> 0 AndAlso unaryOperatorPrecedence > parentPrecedence Then
        Dim operatorToken = NextToken()
        Dim operand = ParseExpression(unaryOperatorPrecedence)
        left = New UnaryExpressionSyntax(operatorToken, operand)
      Else
        left = ParsePrimaryExpression()
      End If
      Do
        Dim precedence = SyntaxFacts.GetBinaryOperatorPrecedence(Current.Kind)
        If precedence = 0 OrElse precedence <= parentPrecedence Then Exit Do
        Dim operatorToken = NextToken()
        Dim right = ParseExpression(precedence)
        left = New BinaryExpressionSyntax(left, operatorToken, right)
      Loop
      Return left
    End Function

    Private Function ParsePrimaryExpression() As ExpressionSyntax

      Select Case Current.Kind
        Case SyntaxKind.OpenParenToken
          Dim left = NextToken()
          Dim expression = ParseExpression()
          Dim right = MatchToken(SyntaxKind.CloseParenToken)
          Return New ParenthesizedExpressionSyntax(left, expression, right)
        Case SyntaxKind.FalseKeyword, SyntaxKind.TrueKeyword
          Dim keywordToken = NextToken()
          Dim value = (keywordToken.Kind = SyntaxKind.TrueKeyword)
          Return New LiteralExpressionSyntax(keywordToken, value)
        Case Else
          Dim numberToken = MatchToken(SyntaxKind.NumberToken)
          Return New LiteralExpressionSyntax(numberToken)
      End Select

    End Function

  End Class

End Namespace